import importlib.metadata

__version__ = importlib.metadata.version("cs336-data")